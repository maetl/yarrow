#!/usr/bin/env php
<?php
/**
 * Yarrow 0.0.3
 * Simple Documentation Generator
 * <http://yarrowdoc.org>
 *
 * Copyright (c) 2010-2011, Mark Rickerby <http://maetl.net>
 * All rights reserved.
 * 
 * This library is free software; refer to the terms in the LICENSE file found
 * with this source code for details about modification and redistribution.
 */

require 'Yarrow/Autoload.php';

ConsoleRunner::main($_SERVER["argv"]);
