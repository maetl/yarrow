#!/usr/bin/env php
<?php
/**
 * Yarrow
 *
 * (c) 2010-2011, Mark Rickerby <http://maetl.net>
 *
 */

require 'Yarrow/Autoload.php';

ConsoleRunner::main();
