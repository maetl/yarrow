<?php

class ConfigurationError extends Exception {}