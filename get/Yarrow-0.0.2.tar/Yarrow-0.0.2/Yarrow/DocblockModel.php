<?php

class DocblockModel {
	private $source;
	
	function __construct($docblock) {
		$this->source = $docblock;
	}
	
}